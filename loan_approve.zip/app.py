from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

model = joblib.load("loan_approve.pkl")


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", prediction_text=None, prediction_class=None, form_data=None)


@app.route("/predict", methods=["POST"])
def predict():
    form_data = {
        "age": request.form.get("age", ""),
        "income": request.form.get("income", ""),
        "credit_score": request.form.get("credit_score", ""),
        "loan_amount": request.form.get("loan_amount", ""),
        "years_employed": request.form.get("years_employed", ""),
    }

    errors = []

    try:
        age = float(form_data["age"])
    except (ValueError, TypeError):
        age = None
        errors.append("Age must be a valid number.")

    try:
        income = float(form_data["income"])
    except (ValueError, TypeError):
        income = None
        errors.append("Annual Income must be a valid number.")

    try:
        credit_score = float(form_data["credit_score"])
    except (ValueError, TypeError):
        credit_score = None
        errors.append("Credit Score must be a valid number.")

    try:
        loan_amount = float(form_data["loan_amount"])
    except (ValueError, TypeError):
        loan_amount = None
        errors.append("Loan Amount must be a valid number.")

    try:
        years_employed = float(form_data["years_employed"])
    except (ValueError, TypeError):
        years_employed = None
        errors.append("Years Employed must be a valid number.")

    if not errors:
        if age is None or age < 18:
            errors.append("Age must be 18 or older.")
        if income is None or income < 0:
            errors.append("Annual Income must be 0 or greater.")
        if credit_score is None or credit_score < 300 or credit_score > 900:
            errors.append("Credit Score must be between 300 and 900.")
        if loan_amount is None or loan_amount <= 0:
            errors.append("Loan Amount must be greater than 0.")
        if years_employed is None or years_employed < 0:
            errors.append("Years Employed must be 0 or greater.")

    if errors:
        return render_template(
            "index.html",
            prediction_text=" ".join(errors),
            prediction_class="error",
            form_data=form_data,
        )

    features = np.array([[income, credit_score, loan_amount, years_employed]])

    prediction = model.predict(features)
    result = int(prediction[0])

    if result == 1:
        prediction_text = "Loan Approved"
        prediction_class = "approved"
    else:
        prediction_text = "Loan Not Approved"
        prediction_class = "rejected"

    return render_template(
        "index.html",
        prediction_text=prediction_text,
        prediction_class=prediction_class,
        form_data=form_data,
    )


if __name__ == "__main__":
    app.run(debug=True)
